$(function() {
	$('.bxslider').bxSlider({
		pager: false,
		infiniteLoop: true
	});
});