$(function() {
	$('[data-toggle="popover"]').popover({ html : true}); 
	
	$('html').on('click', function(e) {
		if (typeof $(e.target).data('original-title') == 'undefined' &&
		   !$(e.target).parents().is('.popover.in')) {
		  $('[data-original-title]').popover('hide');
		}
	});
});

