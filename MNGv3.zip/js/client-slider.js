$(function() {

 	$('.bxslider').bxSlider({
 		 auto: true,
     autoControls: false,
     controls: false,
     pause: 2000,
     infiniteLoop: true,
     pager: false,
 		 useCSS: false,
 		 moveSlides: 1,
 		 minSlides: 2,
		 maxSlides: 8,
		 slideWidth: 170,
		 slideMargin: 10
 	});

});